from flask import Flask

from controllers.routes import simple_page 

app = Flask(__name__)
app.register_blueprint(simple_page)

if __name__ == 'main':
    app.run(debug=True)